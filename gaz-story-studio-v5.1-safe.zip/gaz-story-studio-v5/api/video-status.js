export default async function handler(req,res){
  if(req.method!=='GET') return res.status(405).json({error:'GET only'});
  if(!process.env.AGNES_API_KEY) return res.status(500).json({error:'AGNES_API_KEY is missing'});
  try{
    const {video_id,model_name='agnes-video-2.5-flash'}=req.query;
    if(!video_id) return res.status(400).json({error:'video_id is required'});
    const u=`https://apihub.agnes-ai.com/agnesapi?video_id=${encodeURIComponent(video_id)}&model_name=${encodeURIComponent(model_name)}`;
    const r=await fetch(u,{headers:{Authorization:`Bearer ${process.env.AGNES_API_KEY}`} });
    const data=await r.json();
    const out={...data, video_url:data?.url||null};
    return res.status(r.status).json(out);
  }catch(e){return res.status(500).json({error:e.message});}
}
